// JavaScript Document

  document.createElement('header');
  document.createElement('nav');
  document.createElement('footer');
  document.createElement('article');
  document.createElement('section');
  document.createElement('main');
